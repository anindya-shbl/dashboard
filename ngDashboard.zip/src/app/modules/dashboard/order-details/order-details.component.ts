import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { OrderService } from '../../../services/order.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonService } from '../../../services/common.service';
import { WebEngageService } from '../../../services/web-engage.service';

@Component({
  selector: 'app-order-details',
  templateUrl: './order-details.component.html',
  styleUrl: './order-details.component.scss'
})
export class OrderDetailsComponent implements OnInit {

  orderDetails : any = '';
  orderItems : any = [];
  orderTracker: any = [];
  orderUrl: any = '';
  totalSavings: any = 0;
  isloading: boolean = false;
  cancelReasonList: any=[]
  cancelationReason: any = '';
  cnlsMsg: boolean = false;
  cancelSuccess: boolean =false;

  ItemDiscount : any = 0;
  CouponDiscount : any = 0;
  CouponPromoDesc : any = 0;
  PromoDiscount : any = 0;
  orderInfo : any = '';
  cancelDesc: any = '';
  returnDesc: any = '';

  respMsg: any = '';
  @ViewChild('cnlsRspModal') cnlsRspModal: any;
  @ViewChild('cnlsOrd') cnlsOrd: any;

  constructor(private router: Router, private activatedRoute : ActivatedRoute, private orderService : OrderService, private spinner: NgxSpinnerService, public CommonService: CommonService, private webengageService: WebEngageService){}

  ngOnInit(): void {
    let orderId = this.activatedRoute.snapshot.params['orderID'];
    // let orderId = 'AwIHfl5SHgJvFg==';
    // console.log(orderId, typeof('orderId'))
    if(orderId != undefined || orderId != ''){
      let fd = new FormData();
      fd.append('orderId', atob(orderId));
      this.orderDetailById(fd);
    }
    
  }

  orderDetailById(param: any){
    this.spinner.show();
    this.isloading = true;
    console.log(param);
    this.orderService.getOrderDetailById('webapi/order/viewOrder', param).subscribe((res: any) => {
      res = {"data":{"ShortInfo":{"heading":"Delivery by 27 May 2026","desc":"","colorStatus":"GREEN","color":"#039855","bgColor":"#EBFFF6","cancelButton":{"isVisible":true,"heading":"Cancel Order","desc":""},"returnButton":{"isVisible":false,"heading":"","desc":""}},"OrderHeaders":{"OrderId":101002486468,"OrderDate":"2026-05-26 15:32:09.310","InvoiceId":null,"FullName":"NorthEast Test HB","PatientName":"Anindya Acharya","ItemDiscount":3.86,"OrderAmount":193,"ShippingCharge":0,"CourierCharge":0,"OrderBillAmount":190,"RoundOfSign":"-","RoundOfVal":0.41,"EwalletVal":0,"DueAmount":190,"TypeofPayment":"COD","PaymentMode":"","Addline":" home","City":"Kolkata","StateName":"West Bengal","PinCode":700159,"PromoId":null,"PromoCode":null,"PromoDesc":null,"ApplicationType":"M","OrderType":"O","OrderStatusId":1,"CouponPromoId":null,"CouponPromoCode":null,"CouponPromoDesc":null,"PromoDiscount":0,"CouponDiscount":0,"InvoiceNo":"Not Assigned","IsCourierOrder":0,"DocketNo":"","CompanyName":"","CustOrderStatusDesc":"Pending Order Confirmation","PaidAmount":null,"IsSalesReturnActive":0,"IsEdited":0,"EditComment":"","PayStatusDesc":"","PGTitle":null,"IsRefundInitiated":0,"RefundAmount":null,"RefundInitiatedDate":null,"SalesReturnStatusId":null,"SalesReturnStatusDesc":null,"ReturnUpdatedDate":null,"IsCancel":"Y","SellerMasId":null,"DeliveryDate":"2026-05-27 15:32:09.000","SubscriptionId":null,"SubscriptionDiscount":null,"NickName":" XXX","CustContactNo":8918951655,"Landmark":" csghacdh","ServiceArea":null,"WarehouseId":1,"IsOutStation":0,"IsPrescriptionUploaded":1,"HBId":417212,"ContactNo":6665554443,"HBAddLine":"Test","HBCity":"Kolkata","HBStateName":"West Bengal","HBPinCode":700159,"ConvienceFee":1.27,"SmallOrderFee":0,"AWBNo":null,"TrackingLink":null,"OnlinePaid":null,"ScheduleDeliveryDate":"2026-05-27 15:32:09.000","GiftCardValue":null,"IsJitoCFH":0,"IsTrackReturnAvailable":0,"GigtCardValue":null,"IsOrderTrackAvailable":1,"IsRatingReviewEnabled":0,"IsReorderActive":0,"InvoiceURL":"","PaymentModeOld":"","TypeofPaymentOld":"COD","IsPaynow":1,"0":"","DeliveryMsg":"","RefundMessage":""},"OrderItems":[{"ProductId":17380,"DisplayName":"Horlicks Chocolate Delight Refill Powder 500 gm","MRP":193,"ProductImage":"HORLICKS-CHOCOLATE-DELIGHT-REFIL-1416891831-10016742.jpg","PromoId":null,"PromoCode":null,"PromoDesc":null,"SSCurrencyValue":0,"OrderItemVal":189.14,"OfferPrice":189.14,"CustomProductName":"","Rating":0,"ProductName":"Horlicks Chocolate Delight Refill Powder","CouponPromoId":null,"CouponPromoCode":null,"CouponPromoDesc":null,"IsCustomizeProduct":0,"XplorPoint":0,"XplorPointVal":0,"PrescriptionOTC":"O","InteractiveModule":null,"InteractiveHealthProfileId":null,"MfgGroup":"GLAXO (GSK)","SaltName":"Horlicks","EncodeProdId":"vxu9er","IsGiftableProduct":null,"DosageForm":"Horlicks","SellerMasId":null,"ItemQuantity":1,"ItemDiscount":3.86,"ProductImageURL":"https:\/\/asset.sastasundar.com\/incom\/images\/product\/thumb\/HORLICKS-CHOCOLATE-DELIGHT-REFIL-1416891831-10016742.jpg"}],"trackDetails":[{"OrderStatusHistoryId":10958368,"OrderStatusId":1,"OrderStatusDesc":"Pending Approval by HB","Comments":null,"UpdatedBy":588795,"UpdatedByName":"Anindya Acharya","UpdatedDate":"2026-05-26 15:32:09.310","UserType":"C","0":"","4":""}],"returnUrl":"","OriginalItems":[],"order_track_details":[{"DisplaySequence":1,"StatusType":"Order Placed","orderProcessStatus":1,"lastActiveStatus":1,"orderProcessCancelStatus":0,"UpdatedDate":"Today, 03:32 PM","StatusMessage":""},{"DisplaySequence":2,"StatusType":"Order Confirmed","orderProcessStatus":0,"lastActiveStatus":0,"orderProcessCancelStatus":0,"UpdatedDate":"","StatusMessage":""},{"DisplaySequence":4,"StatusType":"Order Shipped","orderProcessStatus":0,"lastActiveStatus":0,"orderProcessCancelStatus":0,"UpdatedDate":"","StatusMessage":""},{"DisplaySequence":5,"StatusType":"Order Delivered","orderProcessStatus":0,"lastActiveStatus":0,"orderProcessCancelStatus":0,"UpdatedDate":"","StatusMessage":""}],"RefundHygiene":[]},"message":"success","response_code":"0"};
      // this.orderDetails = res;
      console.log(res);
      if(res && res['response_code'] == 0){
        this.orderDetails = res['data']['OrderHeaders'];
        this.orderItems = res['data']['OrderItems'];
        this.orderTracker = res['data']['order_track_details'];
        this.orderInfo = res['data']['ShortInfo'];
        // console.log(this.orderDetails, this.orderItems, this.orderTracker);
        // this.totalSavings = res['data']['OrderHeaders']['ItemDiscount'] +  res['data']['OrderHeaders']['PromoDiscount'];
        this.ItemDiscount= res['data']['OrderHeaders']['ItemDiscount'] == null ? 0 : res['data']['OrderHeaders']['ItemDiscount'];
        this.CouponDiscount = res['data']['OrderHeaders']['CouponDiscount']== null ? 0 : res['data']['OrderHeaders']['CouponDiscount'];
        // this.CouponPromoDesc = res['data']['OrderHeaders']['CouponPromoDesc']== null ? 0 : res['data']['OrderHeaders']['CouponPromoDesc'];
        this.PromoDiscount = res['data']['OrderHeaders']['PromoDiscount']== null ? 0 : res['data']['OrderHeaders']['PromoDiscount'];
        if(this.orderInfo['returnButton']['desc'] != undefined && this.orderInfo['returnButton']['desc'] != null && this.orderInfo['returnButton']['desc'] != ''){
          this.returnDesc = this.orderInfo['returnButton']['desc'];
        }
        if(this.orderInfo['cancelButton']['desc'] != undefined && this.orderInfo['cancelButton']['desc'] != null && this.orderInfo['cancelButton']['desc'] != ''){
          this.cancelDesc = this.orderInfo['cancelButton']['desc'];
        }

        this.totalSavings = this.ItemDiscount + this.CouponDiscount + this.PromoDiscount;
        // console.log(this.totalSavings)
        this.spinner.hide();
        this.isloading = false;
        if(this.orderDetails.OrderStatusId != 8 && this.orderDetails.OrderStatusId != 5){
          this.getcancelReasonList();
        }
        this.orderDetailsWebEngage(this.orderDetails, this.orderItems)
      } else {
        this.orderDetails = '';
        this.orderItems = [];
        this.orderTracker = [];
        this.orderInfo = '';
        this.orderUrl = '';
        this.totalSavings = 0;
        this.spinner.hide();
        this.isloading = false;
      }
    })
  }

  getInvoice(invoiceId: any){
    // console.log(invoiceId)
  }
  getPGlistForCOD(id: any){
    let orderId = btoa(id)
    this.router.navigate(['customers/dashboard/paynow', orderId]);
  }
  getcancelReasonList(){
    // this.orderService.getcancelReasonList('customers/order/cancelOrderReason').subscribe((res: any) => {
    this.orderService.getcancelReasonList('webapi/order/cancelOrderReason').subscribe((res: any) => {
      // console.log(res);
      // if(res && res['result']['rs']['Success'] == 1){
      //   this.cancelReasonList = res['result']['rs']['order_cancel']
      // }
      if(res && res['status'] == 200){
        this.cancelReasonList = res['data']['OrderData']
      }
    })
  }

  canceOrder() {
    this.cancelSuccess =false;
    if(this.cancelationReason != ''){
      let fd = new FormData();
    fd.append('orderId', this.orderDetails.OrderId);
    fd.append('cancelReason', this.cancelationReason);
    fd.append('payment_method', this.orderDetails.TypeofPayment);
    this.spinner.show();
    this.isloading = true;
    // this.orderService.cancelOrder('customers/order/cancelOrder', fd).subscribe((res: any) => {
    this.orderService.cancelOrder('webapi/order/cancelOrder', fd).subscribe((res: any) => {
      // this.orderDetails = res;
      // console.log(res);
      if(res && res['status'] == 200){
        this.respMsg = 'Order cancelled successfully';
        this.cnlsRspModal.nativeElement.click();
        this.spinner.hide();
        this.cancelationReason = '';
        this.cnlsOrd.nativeElement.value = ''
        this.cancelSuccess =true;
        // this.router.navigate(['/Dashboard/MyOrders'])
      } else {
        this.spinner.hide();
        this.respMsg = res.message;
        this.cnlsRspModal.nativeElement.click();
        this.cancelationReason = '';
        this.cnlsOrd.nativeElement.value = ''
        // this.isloading = false;
      }
    })
    }else{
      this.cnlsMsg = true;
    }
  }

  setCancelReason(evnt: any){
    this.cancelationReason = evnt.target.value;
    if(this.cancelationReason == ''){
      this.cnlsMsg = true;
    }else{
      this.cnlsMsg = false;
    }
  }

  cancelReset(){
    this.cancelationReason = '';
    this.cnlsOrd.nativeElement.value = '';
    if(this.cancelSuccess == true){
      this.router.navigate(['customers/dashboard/orderlist'])
    }
  }

  returnRequest(orderid: any, invoiceid: any){
    // console.log(orderid, invoiceid);
    let orderID = btoa(orderid);
    let invoiceID = btoa(invoiceid)

    // let orderID = btoa('101002497677');
    // let invoiceID = btoa('2238332');
    this.router.navigate(['customers/dashboard/returnrequest', orderID, invoiceID]);
  }

  viewTrackDetails(link: any){
    // let link1 = 'https://sastasundar.com/dabur-chyawanprash-jar-3x-immunity-action-2-kg-dabur-india-limited/p/ra4sqdl'
    // window.open(link1, "_blank");
    window.open(link, "_blank");
    this.trackOrderWebEngage()

  }


  orderDetailsWebEngage(dtls: any, items: any){
    let webData = {
      'Order ID' : dtls.OrderId.toString(),
      'Product Details' : items ? items : [] ,
      'Status' : dtls.CustOrderStatusDesc
    }
    this.webengageService.trackEvent('My Order Details Viewed', webData);
  }

  trackOrderWebEngage(){
    this.webengageService.trackEvent('Track Order Status Clicked', {});
  }

}
